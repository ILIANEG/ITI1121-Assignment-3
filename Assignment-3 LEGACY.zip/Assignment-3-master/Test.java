public class Test {
	public static void main(String[] args) {
		TicTacToeGame g = new TicTacToeGame(4, 3, 3);
		ComputerRandomPlayer computerPlayer = new ComputerRandomPlayer();
		while(g.getGameState() == GameState.PLAYING) {
			computerPlayer.play(g);
		}
		System.out.println("***************************************");
		System.out.println();
		System.out.println(g.toString());
		System.out.println();
		System.out.println("***************************************");
		System.out.println();
		//System.out.println(Symmetry.reverseRows(g).toString());
		System.out.println();
		System.out.println("***************************************");
		System.out.println();
		System.out.println(Symmetry.reverseColumns(g).toString());
		System.out.println();
		System.out.println("***************************************");
		System.out.println();
		System.out.println(Symmetry.inverseBoard(g).toString());
		System.out.println();
		System.out.println("***************************************");
		System.out.println();
	}
}
