public class Symmetry
{
	public static TicTacToeGame reverseRows(TicTacToeGame game)
	{
		int count = 0;
		//Define working arrays:
		CellValue[] boardOfGame = new CellValue[game.lines * game.columns];
		CellValue[] reverseRows = new CellValue[game.lines * game.columns];

		//Populate board array:
		for (int i = 0; i < boardOfGame.length; i++) boardOfGame[i] = game.valueAt(i);

		//Populate horizontally reversed board array:
		for (int i = 0; i < game.lines; i++) for (int j = game.columns - 1; j >= 0; j--)
		{
			reverseRows[count++/*(game.columns * i) + j*/] = boardOfGame[i * game.columns + j];
		}

		//Return array with new game instance:
		return new TicTacToeGame(game, reverseRows);
	}


	public static TicTacToeGame reverseColumns(TicTacToeGame game)
	{
		int count = 0;
		//Define working arrays:
		CellValue[] boardOfGame = new CellValue[game.lines * game.columns];
		CellValue[] reverseColumns = new CellValue[game.lines * game.columns];

		//Populate board array:
		for (int i = 0; i < boardOfGame.length; i++) boardOfGame[i] = game.valueAt(i);

		//Populate vertically reversed board array:
		for (int i = game.lines - 1; i >= 0; i--) for (int j = 0; j < game.columns; j++)
		{
			reverseColumns[count++/*(game.columns * i) + j*/] = boardOfGame[i * game.columns + j];
		}

		//Return array with new game instance:
		return new TicTacToeGame(game, reverseColumns);
	}

	public static TicTacToeGame inverseBoard(TicTacToeGame game)
	{
		int count = 0;
		//Define working arrays:
		CellValue[] boardOfGame = new CellValue[game.lines * game.columns];
		CellValue[] invertBoard = new CellValue[game.lines * game.columns];

		//Populate board array:
		for (int i = 0; i < boardOfGame.length; i++) boardOfGame[i] = game.valueAt(i);

		//Populate diagonally inverted board array:
		for (int i = game.lines - 1; i >= 0; i--) for (int j = game.columns - 1; j >= 0; j--)
		{
			invertBoard[count++/*(game.columns * i) + j*/] = boardOfGame[i * game.columns + j];
		}

		//Return array with new game instance:
		return new TicTacToeGame(game,invertBoard);
	}
}
