import java.util.Random;
import java.io.Console;

public class Utils
{
	public static final Random generator = new Random();
	public static final Console console = System.console();
	public static final String NEW_LINE = System.getProperty("line.separator");

	//horizontaly flips array of integers passed in arguments
	public static void horizontalFlip(int lines, int columns, int[] transformedBoard)
	{
		//NullPointerException if transformedBoard in null
		if (transformedBoard == null) {
			throw new NullPointerException("Can not flip uninitialized board");
		}
		//temporary indexes
		int a, b;
		//temporary integer
		int tmp;
		//* flipping algorythm swaps elements in the board, since swap changes 2 elements at a time
		//* We do not need to iterate over all lines (only half of them)
		for (int i = lines; i > lines / 2; i--) for (int j = 0; j < columns; j++)
		{
			a = (lines - i) * columns + j;
			b = (i - 1) * columns + j;
			tmp = transformedBoard[a];
			transformedBoard[a] = transformedBoard[b];
			transformedBoard[b] = tmp;
		}
	}

	//vertically flips the board
	public static void verticalFlip(int lines, int columns, int[] transformedBoard)
	{
		//check for NullPointer Exception
		if (transformedBoard == null) {
			throw new NullPointerException("Can not flip uninitiaized board");
		}
		int a, b, tmp;

		//* By similar reasoning as in horizontal flip we do not need to iterate over every column
		//* in every given line, just through half of columns
		for (int i = 0; i < lines; i++) for (int j = columns; j > columns / 2; j--)
		{
			a = i * columns + (columns - j);
			b = i * columns + (j - 1);
			tmp = transformedBoard[a];
			transformedBoard[a] = transformedBoard[b];
			transformedBoard[b] = tmp;
		}
	}

	public static void rotate(int lines, int columns, int[] transformedBoard)
	{
		if (transformedBoard == null) {
			throw new NullPointerException("Can not rotate uninitiaized board");
		}
		if (lines == columns)
		{
			int a, b, tmp;
			//* Rotating algorythm creates the Transpose of the board by simple (i, j) = (j, i) but in 1d
			//* Transpose board is then vertically flipped which results in 90 deg rotation
			for (int i = 0; i < lines; i++) for (int j = i; j < lines; j++)
			{
				a = i * columns + j;
				b = j * columns + i;
				tmp = transformedBoard[a];
				transformedBoard[a] = transformedBoard[b];
				transformedBoard[b] = tmp;
			}
			verticalFlip(lines, columns, transformedBoard);
		}

		else
		{
			horizontalFlip(lines, columns, transformedBoard);
			verticalFlip(lines, columns, transformedBoard);
		}
	}
}
