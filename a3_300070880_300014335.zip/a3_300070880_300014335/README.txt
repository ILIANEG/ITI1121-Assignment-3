Student name: Nick Bailuc, Illia Negovora
Student number: 300014335, 300070880
Course code: ITI1121
Lab section: C-02, C-01

(1) TicTacToe.java generates all possible TicTacToe games on specified nxm board excluding symmetrical equivalences.
(2) Symmetrical equivalences are found using method equalsWithSymmetry() is TicTacToeGame.java.
(3) Method equalsWithSymmetry() relies on 90 degree rotation, horizontal flip and vertical flip of the board of 
    integers, which later maps to an elements on actual TicTacToeBoard through technique known as indirection.
(4) Methods rotate(), horizontalFlip() and vericalFlip() are implemented in Utils.java as static method.
