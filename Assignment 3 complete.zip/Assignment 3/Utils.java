import java.util.Random;
import java.io.Console;

public class Utils {
	public static final Random generator = new Random();
	public static final Console console = System.console();
	public static final String NEW_LINE = System.getProperty("line.separator");

	public static void verticalFlip(int lines, int columns, int[] transformedBoard) {
		int[] boardIndices = new int[lines * columns];
		int count = 0;
		for (int i = 0; i < lines*columns; i++) {
			boardIndices[i] = transformedBoard[i];
		}
		for (int i = 0; i < lines; i++) for (int j = columns - 1; j >= 0; j--)
		{
			transformedBoard[count++] = boardIndices[i * columns + j];
		}
	}
	public static void horizontalFlip(int lines, int columns, int[] transformedBoard) {
		int[] boardIndices = new int[lines * columns];
		int count = 0;
		for (int i = 0; i < lines*columns; i++) {
			boardIndices[i] = transformedBoard[i];
		}
		for (int i = lines - 1; i >= 0; i--) for (int j = 0; j < columns; j++)
		{
			transformedBoard[count++] = boardIndices[i * columns + j];
		}
	}
	public static void rotate(int lines, int columns, int[] transformedBoard) {
		if (lines == columns) {
			int[] boardIndices = new int[lines * columns];
			int count = 0;
			for (int i = 0; i < lines*columns; i++) {
				boardIndices[i] = transformedBoard[i];
			}
			for (int i = 0; i < columns; i++) for (int j = 0; j < lines; j++) {
				transformedBoard[count++] = boardIndices[j * lines + i];
			}
		} else
			horizontalFlip(lines, columns, transformedBoard);
			verticalFlip(lines, columns, transformedBoard);
	}
}
