class test
{
	public static void main(String[] args)
	{
		//Instance Variables:
		char[] boardOfGame = new char[]{'0','1','2','3','4','5','6','7','8','9',
										'A','B','C','D','E','F','G','H','I','J',
										'K','L','M','N','O','P','Q','R','S','T',
										'U','V','W','X','Y','Z'};
		int gamelines = 6, gamecolumns = 6;
		String reverseColumns = "", reverseRows = "", invertBoard = "";

		//Algorithms:
		for (int i = 0; i < gamelines; i++) for (int j = gamecolumns - 1; j >= 0; j--)
		{
			reverseRows += boardOfGame[i * gamecolumns + j];
		}

		for (int i = gamelines - 1; i >= 0; i--) for (int j = 0; j < gamecolumns; j++)
		{
			reverseColumns += boardOfGame[i * gamecolumns + j];
		}

		for (int i = gamelines - 1; i >= 0; i--) for (int j = gamecolumns - 1; j >= 0; j--)
		{
			invertBoard += boardOfGame[i * gamecolumns + j];
		}

		//stdout:
		System.out.println("boardOfGame:");
		for (int i = 0; i < gamelines * gamecolumns; i++)
		{
			if ((i+1) % gamecolumns == 0) System.out.println(boardOfGame[i]);
			else System.out.print(boardOfGame[i]);
		}

		System.out.println("\nreverseRows:");
		for (int i = 0; i < gamelines * gamecolumns; i++)
		{
			if ((i+1) % gamecolumns == 0) System.out.println(reverseRows.charAt(i));
			else System.out.print(reverseRows.charAt(i));
		}

		System.out.println("\nreverseColumns:");
		for (int i = 0; i < gamelines * gamecolumns; i++)
		{
			if ((i+1) % gamecolumns == 0) System.out.println(reverseColumns.charAt(i));
			else System.out.print(reverseColumns.charAt(i));
		}

		System.out.println("\ninvertBoard:");
		for (int i = 0; i < gamelines * gamecolumns; i++)
		{
			if ((i+1) % gamecolumns == 0) System.out.println(invertBoard.charAt(i));
			else System.out.print(invertBoard.charAt(i));
		}
	}
}
